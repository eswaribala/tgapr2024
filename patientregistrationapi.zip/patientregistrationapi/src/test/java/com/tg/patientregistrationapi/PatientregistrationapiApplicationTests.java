package com.tg.patientregistrationapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientregistrationapiApplicationTests {

	@Test
	void contextLoads() {
	}

}

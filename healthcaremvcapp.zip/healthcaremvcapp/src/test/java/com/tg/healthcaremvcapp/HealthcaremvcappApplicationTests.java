package com.tg.healthcaremvcapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcaremvcappApplicationTests {

	@Test
	void contextLoads() {
	}

}
